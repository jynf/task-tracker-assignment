import { useState } from "react";
import "./App.css";

import Header from "./components/Header";
import ProjectForm from "./components/ProjectForm";
import ProjectList from "./components/ProjectList";

function App() {
  // current theme and state
  const [view, setView] = useState("dashboard");
  const [darkMode, setDarkMode] = useState(true);

  // add intial projects for demonstration
  const [projects, setProjects] = useState([
    {
      id: 1,
      name: "Personal Portfolio Website",
      idea: "Build a website to showcase my programming projects.",
      tasks: [
        { id: 1, title: "Create homepage", completed: true },
        { id: 2, title: "Add project section", completed: false }
      ]
    },
    {
      id: 2,
      name: "Study Planner App",
      idea: "Create an app to organize study sessions.",
      tasks: [
        { id: 3, title: "Create task list", completed: false }
      ]
    }
  ]);

  // add project, projects have tasks grouped into them
  function addProject(name, idea) {
  const newProject = {
    id: Date.now(),
    name: name,
    idea: idea,
    tasks: []
  };

  const updatedProjects = [];

  for (let i = 0; i < projects.length; i++) {
    updatedProjects.push(projects[i]);
  }

  updatedProjects.push(newProject);

  setProjects(updatedProjects);
}

  // add task to a project
 function addTask(projectId, title) {
  const newTask = {
    id: Date.now(),
    title: title,
    completed: false
  };

  const updatedProjects = projects.map(function(project) {

    if (project.id === projectId) {

      const updatedTasks = [];

      for (let i = 0; i < project.tasks.length; i++) {
        updatedTasks.push(project.tasks[i]);
      }
      updatedTasks.push(newTask);

      return {
        id: project.id,
        name: project.name,
        idea: project.idea,
        tasks: updatedTasks
      };
    }
    return project;
  });

  // Update React state
  setProjects(updatedProjects);
}

  // set a task as complete or incomplete
  function toggleTask(projectId, taskId) {
  const updatedProjects = projects.map(function(project) {

    if (project.id === projectId) {

      //creates an array of the tasks
      const updatedTasks = project.tasks.map(function(task) {

        if (task.id === taskId) {

          // create a task with the same id and title, but opposite completion value
          return {
            id: task.id,
            title: task.title,
            completed: !task.completed
          };
        }
        return task;
      });

      //return project with properties
      return {
        id: project.id,
        name: project.name,
        idea: project.idea,
        tasks: updatedTasks
      };
    }
    return project;
  });

  setProjects(updatedProjects);
}

  //gets number of projects and completions to display at top
  const totalTasks = projects.reduce(
    (total, project) => total + project.tasks.length,
    0
  );

  const completedTasks = projects.reduce(
    (total, project) =>
      total + project.tasks.filter((task) => task.completed).length,
    0
  );

  return (
    <div className={darkMode ? "app dark-mode" : "app"}>
      <Header
        view={view}
        setView={setView}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {view === "dashboard" ? (
        <main>
          <h2>My Programming Projects</h2>
          <p>
            Keep track of what needs to be done in different projects
          </p>

          <div className="stats">
            <div className="stat">
              <h3>{projects.length}</h3>
              <p>Projects</p>
            </div>

            <div className="stat">
              <h3>{totalTasks}</h3>
              <p>Total Tasks</p>
            </div>

            <div className="stat">
              <h3>{completedTasks}</h3>
              <p>Completed Tasks</p>
            </div>
          </div>

          <ProjectForm addProject={addProject} />

          <ProjectList
            projects={projects}
            addTask={addTask}
            toggleTask={toggleTask}
          />
        </main>
      ) : (
        <main>
          <h2>About This Project</h2>

          <p>
            This application allows someone to create tasks for their projects so that they can easily manage their progress.
          </p>
        </main>
      )}
    </div>
  );
}

export default App;